# Go2 VSLAM 全链路导航回归报告

- 总结果：失败
- 目标：0/4
- 家具碰撞：0
- 回环：2
- 建图进度：14/14
- 建图失败原因：无
- 定位失败原因：saved-map localization or occupancy grid unavailable
- 回到起点误差：不可用
- 最终航向误差：29.99°
- 遮挡后重定位：未恢复
- 全程最大定位漂移：0.158 m

| 检查 | 结果 |
|---|---:|
| mapping_finished | PASS |
| database_saved | PASS |
| localization_finished | FAIL |
| all_goals_reached | FAIL |
| zero_furniture_collisions | PASS |
| return_position | FAIL |
| return_yaw | FAIL |
| tracking_loss_observed | FAIL |
| relocalized | FAIL |
| recovery_time | FAIL |
| loop_closure | PASS |

未通过：localization_finished、all_goals_reached、return_position、return_yaw、tracking_loss_observed、relocalized、recovery_time

全局导航使用 RTAB-Map 位姿和保存的占据栅格，局部避障使用模拟距离扫描。MuJoCo 真值位姿只用于评分，不校正导航；底层 RL 保留模拟本体感知和地形观测。
